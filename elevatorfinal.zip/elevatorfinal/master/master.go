package master


func masterHallOrders(buttonType elevio.ButtonType, )

func masterFloorReached()

package main

import "./fsm"
//import "./network"
/*import "./elevio"

import "./queue"
import "fmt"
import "time"*/

func main(){
	fsm.Fsm()
	//network.Network()
}
